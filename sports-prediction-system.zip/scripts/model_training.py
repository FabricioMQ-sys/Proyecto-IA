# PROYECTO DE INTELIGENCIA ARTIFICIAL
# Este script representa la implementación del modelo en Python 
# requerida por la documentación del proyecto.

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import sys

def train_and_predict(dataset_path, home_team, away_team):
    """
    Entrena un modelo Random Forest con el dataset proporcionado y realiza una predicción.
    """
    try:
        # 1. Carga de Datos
        print(f"Cargando dataset: {dataset_path}...")
        df = pd.read_csv(dataset_path)
        
        # Validar columnas necesarias
        required_cols = ['HomeTeam', 'AwayTeam', 'FTHG', 'FTAG']
        if not all(col in df.columns for col in required_cols):
            # Intentar mapear nombres comunes en español si no están los estándar en inglés
            column_map = {
                'Local': 'HomeTeam', 'Visitante': 'AwayTeam', 
                'GolesLocal': 'FTHG', 'GolesVisita': 'FTAG'
            }
            df.rename(columns=column_map, inplace=True)
            
        # 2. Preprocesamiento
        # Crear variable objetivo: 'H' (Home Win), 'D' (Draw), 'A' (Away Win)
        conditions = [
            (df['FTHG'] > df['FTAG']),
            (df['FTHG'] < df['FTAG'])
        ]
        choices = ['H', 'A']
        df['FTR'] = np.select(conditions, choices, default='D')
        
        # Codificar equipos a números
        le = LabelEncoder()
        all_teams = pd.concat([df['HomeTeam'], df['AwayTeam']]).unique()
        le.fit(all_teams)
        
        df['HomeTeamCode'] = le.transform(df['HomeTeam'])
        df['AwayTeamCode'] = le.transform(df['AwayTeam'])
        
        # Características (Features) para el modelo
        # En un modelo real complejo usaríamos medias móviles, rachas, etc.
        # Aquí usamos identificadores de equipo para capturar la "fuerza" inherente histórica
        X = df[['HomeTeamCode', 'AwayTeamCode']]
        y = df['FTR']
        
        # 3. Entrenamiento del Modelo
        print("Entrenando modelo Random Forest...")
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        clf = RandomForestClassifier(n_estimators=100, random_state=42)
        clf.fit(X_train, y_train)
        
        # Evaluación básica
        accuracy = accuracy_score(y_test, clf.predict(X_test))
        print(f"Precisión del modelo: {accuracy:.2f}")
        
        # 4. Predicción
        if home_team not in le.classes_ or away_team not in le.classes_:
            return "Error: Uno o ambos equipos no existen en el dataset histórico."
            
        home_code = le.transform([home_team])[0]
        away_code = le.transform([away_team])[0]
        
        prediction_code = clf.predict([[home_code, away_code]])[0]
        probs = clf.predict_proba([[home_code, away_code]])[0]
        
        result_map = {'H': home_team, 'A': away_team, 'D': 'Empate'}
        winner = result_map[prediction_code]
        
        # Obtener probabilidad del ganador
        class_idx = list(clf.classes_).index(prediction_code)
        probability = probs[class_idx] * 100
        
        return {
            "prediction": winner,
            "probability": f"{probability:.1f}%",
            "model_accuracy": f"{accuracy:.2f}"
        }

    except Exception as e:
        return f"Error: {str(e)}"

# Ejemplo de uso si se ejecuta directamente
if __name__ == "__main__":
    if len(sys.argv) > 3:
        path = sys.argv[1]
        home = sys.argv[2]
        away = sys.argv[3]
        result = train_and_predict(path, home, away)
        print("\nResultado de la Predicción:")
        print(result)
    else:
        print("Uso: python model_training.py <path_to_csv> <HomeTeam> <AwayTeam>")
