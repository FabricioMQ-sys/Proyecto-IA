import { PredictionForm } from "@/components/prediction-form"
import { Credits } from "@/components/credits"
import { GraduationCap, Trophy } from "lucide-react"

export default function Page() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
      <header className="bg-gradient-to-r from-red-600 to-red-800 text-white py-8 shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-3 mb-2">
            <Trophy className="h-8 w-8 text-yellow-400" />
            <h1 className="text-3xl font-bold tracking-tight">FutbolIA Perú</h1>
          </div>
          <p className="text-red-100 max-w-2xl text-lg">
            Sistema de Predicción de Resultados en la Liga Peruana de Fútbol mediante Inteligencia Artificial
          </p>
        </div>
      </header>

      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="grid gap-8 md:grid-cols-[2fr_1fr]">
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="p-6 border-b border-slate-100">
                <h2 className="text-xl font-semibold flex items-center gap-2">
                  <GraduationCap className="h-5 w-5 text-red-600" />
                  Panel de Predicción
                </h2>
                <p className="text-sm text-slate-500 mt-1">
                  Sube tu dataset histórico y selecciona los equipos para obtener un pronóstico.
                </p>
              </div>
              <div className="p-6">
                <PredictionForm />
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
              <h3 className="font-semibold mb-4 text-slate-800">Sobre el Proyecto</h3>
              <p className="text-sm text-slate-600 leading-relaxed mb-4">
                Este sistema utiliza algoritmos de aprendizaje estadístico para analizar patrones históricos en la Liga
                1 Peruana.
              </p>
              <p className="text-sm text-slate-600 leading-relaxed">
                El modelo considera factores como localía, historial de enfrentamientos y rendimiento reciente para
                calcular la probabilidad de victoria.
              </p>
            </div>

            <Credits />
          </div>
        </div>
      </main>

      <footer className="bg-slate-900 text-slate-400 py-6 text-center text-sm">
        <p>© 2025 FutbolIA Perú - Todos los derechos reservados</p>
      </footer>
    </div>
  )
}
