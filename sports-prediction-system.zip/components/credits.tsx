import { Users, BookOpen, Award } from "lucide-react"

export function Credits() {
  return (
    <div className="bg-slate-800 text-white rounded-xl shadow-lg overflow-hidden">
      <div className="bg-red-700 px-6 py-3">
        <h3 className="font-bold text-center uppercase tracking-wide text-sm">Créditos del Proyecto</h3>
      </div>
      <div className="p-6 space-y-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-red-300 mb-1">
            <Award className="h-4 w-4" />
            <span className="text-xs font-bold uppercase tracking-wider">Proyecto</span>
          </div>
          <p className="font-medium text-lg leading-tight">PROYECTO DE INTELIGENCIA ARTIFICIAL</p>
        </div>

        <div className="space-y-1">
          <div className="flex items-center gap-2 text-red-300 mb-1">
            <BookOpen className="h-4 w-4" />
            <span className="text-xs font-bold uppercase tracking-wider">Docente / Curso</span>
          </div>
          <p className="font-semibold">SAGASTEGUI CHIGNE TEOBALDO</p>
          <p className="text-slate-300 text-sm">Inteligencia Artificial: Principios y Tecnicas...</p>
        </div>

        <div className="space-y-2 pt-2 border-t border-slate-700">
          <div className="flex items-center gap-2 text-red-300 mb-1">
            <Users className="h-4 w-4" />
            <span className="text-xs font-bold uppercase tracking-wider">Alumnos</span>
          </div>
          <ul className="space-y-1 text-sm text-slate-200">
            <li>Mondragon Tirado Henry</li>
            <li>Vasquez Castillo Jherson</li>
            <li>Serrano Salgado Luiggi Stefano</li>
            <li>Melendez Quezada, Fabricio</li>
            <li>Asunción Chira, Luis Gerardo</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
