"use client"

import type React from "react"

import { useState } from "react"
import { Upload, ArrowRight, Loader2, AlertCircle, CheckCircle2, FileText, Database, TrendingUp } from "lucide-react"
import Papa from "papaparse"

interface TeamStats {
  name: string
  matches: number
  wins: number
  draws: number
  losses: number
  goalsFor: number
  goalsAgainst: number
}

interface DatasetStats {
  totalMatches: number
  totalTeams: number
  avgGoalsHome: number
  avgGoalsAway: number
  homeWinRate: number
  drawRate: number
  awayWinRate: number
}

interface Match {
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  winner: "home" | "away" | "draw"
}

export function PredictionForm() {
  const [file, setFile] = useState<File | null>(null)
  const [teams, setTeams] = useState<string[]>([])
  const [matches, setMatches] = useState<Match[]>([])
  const [datasetStats, setDatasetStats] = useState<DatasetStats | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showExample, setShowExample] = useState(false)

  const [selectedHome, setSelectedHome] = useState("")
  const [selectedAway, setSelectedAway] = useState("")
  const [prediction, setPrediction] = useState<{
    winner: string
    probability: number
    reasoning: string
  } | null>(null)

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0]
    if (!uploadedFile) return

    setLoading(true)
    setError(null)
    setFile(uploadedFile)

    // Reset state
    setTeams([])
    setMatches([])
    setDatasetStats(null) // Reset stats
    setSelectedHome("")
    setSelectedAway("")
    setPrediction(null)

    Papa.parse(uploadedFile, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        try {
          processData(results.data)
          setLoading(false)
        } catch (err) {
          setError(
            "Error al procesar el archivo. Asegúrate que tenga columnas como 'HomeTeam', 'AwayTeam', 'FTHG' (goles local), 'FTAG' (goles visita).",
          )
          setLoading(false)
        }
      },
      error: () => {
        setError("Error al leer el archivo CSV")
        setLoading(false)
      },
    })
  }

  const processData = (data: any[]) => {
    const uniqueTeams = new Set<string>()
    const processedMatches: Match[] = []

    let totalHomeGoals = 0
    let totalAwayGoals = 0
    let homeWins = 0
    let draws = 0
    let awayWins = 0

    data.forEach((row) => {
      // Adapt to common CSV headers for football data
      const home = row.HomeTeam || row.Local || row.Home
      const away = row.AwayTeam || row.Visitante || row.Away
      const hGoal = Number.parseInt(row.FTHG || row.GolesLocal || row.HG || "0")
      const aGoal = Number.parseInt(row.FTAG || row.GolesVisita || row.AG || "0")

      if (home && away) {
        uniqueTeams.add(home)
        uniqueTeams.add(away)

        totalHomeGoals += hGoal
        totalAwayGoals += aGoal

        let winner: "home" | "away" | "draw" = "draw"
        if (hGoal > aGoal) {
          winner = "home"
          homeWins++
        } else if (aGoal > hGoal) {
          winner = "away"
          awayWins++
        } else {
          draws++
        }

        processedMatches.push({
          homeTeam: home,
          awayTeam: away,
          homeScore: hGoal,
          awayScore: aGoal,
          winner,
        })
      }
    })

    if (processedMatches.length === 0) {
      throw new Error("No valid match data found")
    }

    setTeams(Array.from(uniqueTeams).sort())
    setMatches(processedMatches)

    setDatasetStats({
      totalMatches: processedMatches.length,
      totalTeams: uniqueTeams.size,
      avgGoalsHome: Number((totalHomeGoals / processedMatches.length).toFixed(2)),
      avgGoalsAway: Number((totalAwayGoals / processedMatches.length).toFixed(2)),
      homeWinRate: Number(((homeWins / processedMatches.length) * 100).toFixed(1)),
      drawRate: Number(((draws / processedMatches.length) * 100).toFixed(1)),
      awayWinRate: Number(((awayWins / processedMatches.length) * 100).toFixed(1)),
    })
  }

  const predictResult = () => {
    if (!selectedHome || !selectedAway) return

    setLoading(true)

    // Simulate processing time
    setTimeout(() => {
      const homeStats = getTeamStats(selectedHome)
      const awayStats = getTeamStats(selectedAway)
      const h2h = getHeadToHead(selectedHome, selectedAway)

      // Simple algorithm logic (Logistic Regression simplified approximation)
      let homeScore = 0
      let awayScore = 0

      // 1. Recent Performance Weight (Normalized)
      const homeWinRate = homeStats.matches > 0 ? homeStats.wins / homeStats.matches : 0
      const awayWinRate = awayStats.matches > 0 ? awayStats.wins / awayStats.matches : 0

      homeScore += homeWinRate * 10
      awayScore += awayWinRate * 10

      // 2. Head to Head Weight
      if (h2h.matches > 0) {
        homeScore += (h2h.homeWins / h2h.matches) * 5
        awayScore += (h2h.awayWins / h2h.matches) * 5
      }

      // 3. Home Advantage (Statistical constant ~10-15% boost)
      homeScore += 1.5

      const total = homeScore + awayScore
      const homeProb = (homeScore / total) * 100
      const awayProb = (awayScore / total) * 100

      let resultWinner = "Empate"
      let winProb = 0

      if (Math.abs(homeProb - awayProb) < 5) {
        resultWinner = "Empate"
        winProb = 100 - Math.abs(homeProb - awayProb) // Just a dummy high prob for draw if close
      } else if (homeProb > awayProb) {
        resultWinner = selectedHome
        winProb = homeProb
      } else {
        resultWinner = selectedAway
        winProb = awayProb
      }

      setPrediction({
        winner: resultWinner,
        probability: Math.round(winProb),
        reasoning: `Basado en ${matches.length} partidos históricos. ${selectedHome} muestra un rendimiento del ${Math.round(homeWinRate * 100)}% en general, mientras que ${selectedAway} tiene un ${Math.round(awayWinRate * 100)}%. El factor de localía y los enfrentamientos directos (${h2h.homeWins} vs ${h2h.awayWins}) inclinan la balanza.`,
      })

      setLoading(false)
    }, 1500) // Increased time slightly to make the loader feel more like "processing"
  }

  const getTeamStats = (team: string): TeamStats => {
    const teamMatches = matches.filter((m) => m.homeTeam === team || m.awayTeam === team)
    const wins = teamMatches.filter(
      (m) => (m.homeTeam === team && m.winner === "home") || (m.awayTeam === team && m.winner === "away"),
    ).length
    const draws = teamMatches.filter((m) => m.winner === "draw").length
    const losses = teamMatches.length - wins - draws

    const goalsFor = teamMatches.reduce((acc, m) => acc + (m.homeTeam === team ? m.homeScore : m.awayScore), 0)
    const goalsAgainst = teamMatches.reduce((acc, m) => acc + (m.homeTeam === team ? m.awayScore : m.homeScore), 0)

    return {
      name: team,
      matches: teamMatches.length,
      wins,
      draws,
      losses,
      goalsFor,
      goalsAgainst,
    }
  }

  const getHeadToHead = (home: string, away: string) => {
    const h2h = matches.filter(
      (m) => (m.homeTeam === home && m.awayTeam === away) || (m.homeTeam === away && m.awayTeam === home),
    )

    const homeWins = h2h.filter(
      (m) => (m.homeTeam === home && m.winner === "home") || (m.awayTeam === home && m.winner === "away"),
    ).length
    const awayWins = h2h.filter(
      (m) => (m.homeTeam === away && m.winner === "home") || (m.awayTeam === away && m.winner === "away"),
    ).length

    return { matches: h2h.length, homeWins, awayWins }
  }

  const renderComparisonBar = (label: string, val1: number, val2: number, suffix = "", max = 100) => {
    const p1 = Math.min((val1 / max) * 100, 100)
    const p2 = Math.min((val2 / max) * 100, 100)

    return (
      <div className="mb-4">
        <div className="flex justify-between text-xs font-semibold text-slate-500 mb-1">
          <span>
            {val1.toFixed(1)}
            {suffix}
          </span>
          <span>{label}</span>
          <span>
            {val2.toFixed(1)}
            {suffix}
          </span>
        </div>
        <div className="flex h-2 bg-slate-100 rounded-full overflow-hidden">
          <div style={{ width: "50%" }} className="flex justify-end bg-slate-200">
            <div style={{ width: `${(val1 / (val1 + val2 || 1)) * 100}%` }} className="bg-blue-500 h-full"></div>
          </div>
          <div style={{ width: "50%" }} className="flex justify-start bg-slate-200">
            <div style={{ width: `${(val2 / (val1 + val2 || 1)) * 100}%` }} className="bg-red-500 h-full"></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Upload Section */}
      <div className="space-y-3">
        <div className="flex justify-between items-center px-1">
          <label className="text-sm font-medium text-slate-700">Cargar Dataset Histórico</label>
          <button
            onClick={() => setShowExample(!showExample)}
            className="text-xs text-red-600 hover:text-red-700 font-medium flex items-center gap-1"
          >
            <FileText className="h-3 w-3" />
            {showExample ? "Ocultar formato" : "Ver formato requerido"}
          </button>
        </div>

        {showExample && (
          <div className="bg-slate-100 p-3 rounded-lg text-xs text-slate-600 mb-2 border border-slate-200">
            <p className="font-semibold mb-2">Tu archivo CSV debe tener estas columnas:</p>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-300">
                    <th className="py-1 pr-4">HomeTeam</th>
                    <th className="py-1 pr-4">AwayTeam</th>
                    <th className="py-1 pr-4">FTHG</th>
                    <th className="py-1">FTAG</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="opacity-70">
                    <td className="py-1">Alianza</td>
                    <td className="py-1">Universitario</td>
                    <td className="py-1">1</td>
                    <td className="py-1">2</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${file ? "border-green-500 bg-green-50" : "border-slate-300 hover:border-red-400"}`}
        >
          <input type="file" accept=".csv" onChange={handleFileUpload} className="hidden" id="dataset-upload" />
          <label htmlFor="dataset-upload" className="cursor-pointer block w-full h-full">
            {file ? (
              <div className="flex flex-col items-center text-green-700">
                <CheckCircle2 className="h-10 w-10 mb-2" />
                <p className="font-semibold">{file.name}</p>
                <p className="text-sm opacity-80">{matches.length} partidos cargados</p>
                <p className="text-xs mt-2 text-green-600 underline">Cambiar archivo</p>
              </div>
            ) : (
              <div className="flex flex-col items-center text-slate-500">
                <Upload className="h-10 w-10 mb-2" />
                <p className="font-semibold">Sube tu Dataset (.csv)</p>
                <p className="text-xs mt-1">Debe incluir columnas HomeTeam, AwayTeam, FTHG, FTAG</p>
              </div>
            )}
          </label>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-lg flex items-start gap-3 text-sm">
          <AlertCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
          <p>{error}</p>
        </div>
      )}

      {datasetStats && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm animate-in fade-in slide-in-from-bottom-2">
          <h3 className="flex items-center gap-2 text-sm font-bold text-slate-800 uppercase tracking-wide mb-4">
            <Database className="h-4 w-4 text-blue-500" />
            Análisis del Dataset Procesado
          </h3>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
              <p className="text-xs text-slate-500 mb-1">Total Partidos</p>
              <p className="text-2xl font-bold text-slate-800">{datasetStats.totalMatches}</p>
            </div>
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
              <p className="text-xs text-slate-500 mb-1">Equipos</p>
              <p className="text-2xl font-bold text-slate-800">{datasetStats.totalTeams}</p>
            </div>
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
              <p className="text-xs text-slate-500 mb-1">Goles/Partido (L)</p>
              <p className="text-2xl font-bold text-green-600">{datasetStats.avgGoalsHome}</p>
            </div>
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
              <p className="text-xs text-slate-500 mb-1">Goles/Partido (V)</p>
              <p className="text-2xl font-bold text-red-600">{datasetStats.avgGoalsAway}</p>
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-semibold text-slate-500">Distribución de Resultados Históricos</p>
            <div className="flex h-4 rounded-full overflow-hidden text-[10px] text-white font-bold leading-4 text-center">
              <div
                style={{ width: `${datasetStats.homeWinRate}%` }}
                className="bg-green-500"
                title={`Local: ${datasetStats.homeWinRate}%`}
              >
                {datasetStats.homeWinRate}%
              </div>
              <div
                style={{ width: `${datasetStats.drawRate}%` }}
                className="bg-gray-400"
                title={`Empate: ${datasetStats.drawRate}%`}
              >
                {datasetStats.drawRate}%
              </div>
              <div
                style={{ width: `${datasetStats.awayWinRate}%` }}
                className="bg-red-500"
                title={`Visita: ${datasetStats.awayWinRate}%`}
              >
                {datasetStats.awayWinRate}%
              </div>
            </div>
            <div className="flex justify-between text-xs text-slate-400">
              <span>Victorias Local</span>
              <span>Empates</span>
              <span>Victorias Visita</span>
            </div>
          </div>
        </div>
      )}

      {/* Selection Section */}
      <div
        className={`grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] gap-4 items-end transition-opacity duration-300 ${teams.length ? "opacity-100" : "opacity-50 pointer-events-none"}`}
      >
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">Equipo Local</label>
          <select
            className="w-full p-3 rounded-lg border border-slate-300 bg-white focus:ring-2 focus:ring-red-500 outline-none"
            value={selectedHome}
            onChange={(e) => setSelectedHome(e.target.value)}
          >
            <option value="">Seleccionar...</option>
            {teams.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>

        <div className="flex justify-center pb-3 text-slate-400 font-bold">VS</div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">Equipo Visitante</label>
          <select
            className="w-full p-3 rounded-lg border border-slate-300 bg-white focus:ring-2 focus:ring-red-500 outline-none"
            value={selectedAway}
            onChange={(e) => setSelectedAway(e.target.value)}
          >
            <option value="">Seleccionar...</option>
            {teams.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Action Button */}
      <button
        onClick={predictResult}
        disabled={!selectedHome || !selectedAway || loading}
        className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4 rounded-lg shadow-md disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
      >
        {loading ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin" />
            Analizando datos...
          </>
        ) : (
          <>
            Predecir Resultado
            <ArrowRight className="h-5 w-5" />
          </>
        )}
      </button>

      {/* Result Section */}
      {prediction && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <h3 className="flex items-center gap-2 text-sm font-bold text-slate-800 uppercase tracking-wide mb-6">
              <TrendingUp className="h-4 w-4 text-blue-500" />
              Comparativa de Equipos
            </h3>

            <div className="grid grid-cols-3 gap-2 mb-6 text-center">
              <div className="font-bold text-blue-600 truncate">{selectedHome}</div>
              <div className="text-xs text-slate-400 font-bold self-center">VS</div>
              <div className="font-bold text-red-600 truncate">{selectedAway}</div>
            </div>

            {(() => {
              const hStats = getTeamStats(selectedHome)
              const aStats = getTeamStats(selectedAway)
              const h2h = getHeadToHead(selectedHome, selectedAway)

              const hWinRate = hStats.matches ? (hStats.wins / hStats.matches) * 100 : 0
              const aWinRate = aStats.matches ? (aStats.wins / aStats.matches) * 100 : 0
              const hGoalsAvg = hStats.matches ? hStats.goalsFor / hStats.matches : 0
              const aGoalsAvg = aStats.matches ? aStats.goalsFor / aStats.matches : 0

              return (
                <div className="space-y-4">
                  {renderComparisonBar("Tasa de Victorias Histórica", hWinRate, aWinRate, "%", 100)}
                  {renderComparisonBar("Promedio de Goles a Favor", hGoalsAvg, aGoalsAvg, "", 3)}

                  <div className="bg-slate-50 p-4 rounded-lg mt-4">
                    <p className="text-xs text-center text-slate-500 mb-2 font-semibold">
                      Historial Entre Ambos ({h2h.matches} Partidos)
                    </p>
                    <div className="flex justify-center items-center gap-4">
                      <div className="text-center">
                        <div className="text-xl font-bold text-blue-600">{h2h.homeWins}</div>
                        <div className="text-[10px] text-slate-400">Victorias {selectedHome}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-gray-400">
                          {h2h.matches - h2h.homeWins - h2h.awayWins}
                        </div>
                        <div className="text-[10px] text-slate-400">Empates</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-red-600">{h2h.awayWins}</div>
                        <div className="text-[10px] text-slate-400">Victorias {selectedAway}</div>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })()}
          </div>

          <div className="bg-slate-900 text-white rounded-xl p-6 shadow-xl animate-in fade-in slide-in-from-bottom-4">
            <h3 className="text-center text-slate-400 text-sm uppercase tracking-wider mb-2">
              Predicción Final del Modelo
            </h3>

            <div className="text-center mb-6">
              <div className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-yellow-400 mb-1">
                {prediction.winner}
              </div>
              <p className="text-slate-300">
                {prediction.winner === "Empate" ? "Probabilidad de empate" : "Probabilidad de ganar"}:{" "}
                <span className="text-white font-bold">{prediction.probability}%</span>
              </p>
            </div>

            <div className="bg-slate-800 rounded-lg p-4 text-xs text-slate-400 leading-relaxed border border-slate-700">
              <span className="font-semibold text-slate-300 block mb-1">Justificación Lógica:</span>
              {prediction.reasoning}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
